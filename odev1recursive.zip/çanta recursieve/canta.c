# include<stdio.h>
 
void canta(int esya, float agirlik[], float fiyat[], float kapasite) {
   float canta[20], toplam = 0;
   int sayac1, sayac2;
   for (sayac1 = 0; sayac1 < esya; sayac1++)
      canta[sayac1] = 0.0;
   for (sayac1 = 0; sayac1 < esya; sayac1++) {
      if (agirlik[sayac1] > kapasite)
         break;
      else {
         canta[sayac1] = 1.0;
         toplam = toplam + fiyat[sayac1];
         kapasite = kapasite - agirlik[sayac1];
      }
   }
   if (sayac1 < esya)
      canta[sayac1] = kapasite / agirlik[sayac1];
   toplam = toplam + (canta[sayac1] * fiyat[sayac1]);
   printf("\nToplayacaginiz maksimum fiyat: %.2f", toplam);
}
int main() {
   float agirlik[20], fiyat[20], kapasite;
   int esya, sayac1, sayac2;
   float oran[20], yedek;
   printf("\n----------------------------------------------\n");
   printf("\n  CANTAYI EN PAHALI SEKILDE DOLDURAN PROGRAM\n");
   printf("\n----------------------------------------------\n");
   printf("\nEsya sayisi: ");
   scanf("%d", &esya);
    printf("\nCantanizin kapasitesini giriniz  : ");
   scanf("%fiyat", &kapasite);
   for (sayac1 = 0; sayac1 < esya; sayac1++) {
   	printf("\n%d.Esyanin agirligini giriniz : ",sayac1+1);
    scanf("%fiyat", &agirlik[sayac1]);
    printf("\n%d.Esyanin fiyatini giriniz : ",sayac1+1);
    scanf("%fiyat",&fiyat[sayac1]);
   }
   for (sayac1 = 0; sayac1 < esya; sayac1++) {
      oran[sayac1] = fiyat[sayac1] / agirlik[sayac1];
   }
   for (sayac1 = 0; sayac1 < esya; sayac1++) {
      for (sayac2 = sayac1 + 1; sayac2 < esya; sayac2++) {
         if (oran[sayac1] < oran[sayac2]) {
            yedek = oran[sayac2];
            oran[sayac2] = oran[sayac1];
            oran[sayac1] = yedek;
 
            yedek = agirlik[sayac2];
            agirlik[sayac2] = agirlik[sayac1];
            agirlik[sayac1] = yedek;
 
            yedek = fiyat[sayac2];
            fiyat[sayac2] = fiyat[sayac1];
            fiyat[sayac1] = yedek;
         }
      }
   }
   canta(esya, agirlik, fiyat, kapasite);
   return(0);
}
